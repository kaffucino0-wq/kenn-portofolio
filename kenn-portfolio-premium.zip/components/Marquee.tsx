
export default function Marquee(){
  return(
    <div style={{overflow:"hidden", whiteSpace:"nowrap"}}>
      <div className="animate-marquee">
        DIGITAL CREATIVE • PHOTOGRAPHY • DESIGN • VIDEOGRAPHY •
      </div>
    </div>
  )
}
