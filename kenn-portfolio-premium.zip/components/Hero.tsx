
"use client";
import { motion } from "framer-motion";
import { data } from "@/lib/data";

export default function Hero() {
  return (
    <section style={{height:"100vh", display:"flex", flexDirection:"column", justifyContent:"center", alignItems:"center"}}>
      <motion.h1 initial={{opacity:0,y:50}} animate={{opacity:1,y:0}} transition={{duration:1}}>
        {data.name}
      </motion.h1>
      <p>{data.role}</p>
    </section>
  );
}
