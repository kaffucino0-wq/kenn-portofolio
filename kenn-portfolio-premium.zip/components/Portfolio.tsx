
"use client";
import { motion } from "framer-motion";
import { data } from "@/lib/data";

export default function Portfolio() {
  return (
    <section style={{padding:"40px"}}>
      <h2>My Work</h2>
      <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))", gap:"20px"}}>
        {data.portfolio.map((item,i)=>(
          <motion.div key={i} whileHover={{scale:1.05}}>
            <img src={item.image} style={{width:"100%",height:"200px",objectFit:"cover"}} />
            <p>{item.title}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
