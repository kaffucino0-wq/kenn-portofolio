
import Hero from "@/components/Hero";
import Portfolio from "@/components/Portfolio";
import Marquee from "@/components/Marquee";

export default function Home(){
  return(
    <main>
      <Hero/>
      <Marquee/>
      <Portfolio/>
    </main>
  )
}
